#include "Usb_drv.h"
#include "Descriptores.h"

// Configurar interruppciones generales
// por default estan todas en cero
// poner 1 o 0 para habilitar o dejar deshabilitadas las interrupciones

#define UDIEN_MASK_INI  ( (0<<UPRSME) | (0<<EORSME) | (0<<WAKEUPE) | (1<<EORSTE) | (1<<SOFE) | (0<<SUSPE) )





#if EP0_SIZE == 8   
	#define	EP0_SIZEMASK   0<<4
#elif EP0_SIZE == 16
	#define	EP0_SIZEMASK   1<<4
#elif EP0_SIZE == 32
	#define	EP0_SIZEMASK   2<<4
#elif EP0_SIZE == 64
	#define	EP0_SIZEMASK   3<<4
#endif


#if EP1_SIZE == 8   
	#define	EP1_SIZEMASK   0<<4
#elif EP1_SIZE == 16
	#define	EP1_SIZEMASK   1<<4
#elif EP1_SIZE == 32
	#define	EP1_SIZEMASK   2<<4
#elif EP1_SIZE == 64
	#define	EP1_SIZEMASK   3<<4
#endif


#if EP2_SIZE == 8   
	#define	EP2_SIZEMASK   0<<4
#elif EP2_SIZE == 16
	#define	EP2_SIZEMASK   1<<4
#elif EP2_SIZE == 32
	#define	EP2_SIZEMASK   2<<4
#elif EP2_SIZE == 64
	#define	EP2_SIZEMASK   3<<4
#endif







typedef struct
{
	char	bmRequestType;
	char	bRequest;
	char    wValue[2];
	char	wIndex[2];
	char	wLength[2];
} t_SetupPck;



#ifdef __DEBUGGING__
//Para debugging
//usar solo 1, estan en el orden en que los pediria la compu

//t_SetupPck PaqueteTest = {RQ_DEVICE1,RQ_D_GET_DESCRIPTOR,{0,DT_DEVICE},{0,0},{64,0}};

//t_SetupPck PaqueteTest = {RQ_DEVICE0,RQ_D_SET_ADDRESS,{2,0},{0,0},{0,0}};

//t_SetupPck PaqueteTest = {RQ_DEVICE1,RQ_D_GET_DESCRIPTOR,{0,DT_CONFIG},{0,0},{64,0}};

//t_SetupPck PaqueteTest = {RQ_DEVICE1,RQ_D_GET_DESCRIPTOR,{2,DT_STRING},{0x09,0x04},{64,0}};

t_SetupPck PaqueteTest = {3,RQ_D_GET_DESCRIPTOR,{2,DT_STRING},{0x09,0x04},{64,0}};

#endif




void recuperar_STP_pck(t_SetupPck* Paquete)
{
	Paquete->bmRequestType = UEDATX;
	Paquete->bRequest = UEDATX;
	Paquete->wValue[0] = UEDATX;// primero viene el byte bajo de la palabra
	Paquete->wValue[1] = UEDATX;
	Paquete->wIndex[0] = UEDATX;
	Paquete->wIndex[1] = UEDATX;
	Paquete->wLength[0] = UEDATX;
	Paquete->wLength[1] = UEDATX;
	return;
}






// --------ENDOPOINTS-----------

#define  INTERRUP_EP0_MASK    ( (0<<FLERRE) | (0<<NAKINE) | (0<<NAKOUTE) | (1<<RXSTPE) | (0<<RXOUTE) | (0<<STALLEDE) | (0<<TXINE) )

bool configurar_EP0()
{
	// Configuro EndPoint 0
	SeleccionarEndpoint(EndP0);
//Meter Reset Endpoint
//	DesHabilitarEP();
	HabilitarEndP();
	UECFG0X = (EPT_CONTROL | EPT_OUT);
	UECFG1X = EP0_SIZEMASK;
	SetBit(UECFG1X,ALLOC);

	//interrupciones habilitadas para este endpoint	
	UEIENX = INTERRUP_EP0_MASK;
	//borrar flags de interrupciones
	UEINTX = 0x00;

#ifdef __DEBUGGING__
SetBit(UESTA0X,CFGOK);
Nop();
#endif

	if (IsBitSet(UESTA0X,CFGOK)) return OK;
	else return ERROR;
}


//interrupciones habilitadas para este endpoint	
#define  INTERRUP_EP1_MASK    ( (0<<FLERRE) | (0<<NAKINE) | (0<<NAKOUTE) | (1<<RXSTPE) | (1<<RXOUTE) | (0<<STALLEDE) | (0<<TXINE) )

bool configurar_EP1()
{
	// Configuro EndPoint 1
	SeleccionarEndpoint(EndP1);
//Meter Reset Endpoint
//	DesHabilitarEP();
	HabilitarEndP();
	UECFG0X = (EPT_BULK | EPT_OUT);
	UECFG1X = EP1_SIZEMASK;       // tama�o 8 bytes
	SetBit(UECFG1X,ALLOC);

	UEIENX = INTERRUP_EP1_MASK;
	UEINTX = 0x00;	//borrar flags de interrupciones

	if (IsBitSet(UESTA0X,CFGOK)) return OK;
	else return ERROR;
}

//interrupciones habilitadas para este endpoint	
#define  INTERRUP_EP2_MASK    ( (0<<FLERRE) | (0<<NAKINE) | (0<<NAKOUTE) | (1<<RXSTPE) | (1<<RXOUTE) | (0<<STALLEDE) | (0<<TXINE) )

bool configurar_EP2()
{
	// Configuro EndPoint 2
	SeleccionarEndpoint(EndP2);
//Meter Reset Endpoint
//DesHabilitarEP();
	HabilitarEndP();
	UECFG0X = (EPT_BULK | EPT_OUT);
	UECFG1X = EP2_SIZEMASK|EPT_DOUBLE_BANK;	// tama�o 64 bytes, double bank |EPT_DOUBLE_BANK
	SetBit(UECFG1X,ALLOC);

	UEIENX = INTERRUP_EP2_MASK;
	UEINTX = 0x00;	//borrar flags de interrupciones

	if (IsBitSet(UESTA0X,CFGOK)) return OK;
	else return ERROR;
}

//--------------


void send_device_descriptor(t_SetupPck* Paquete)
{
	PGM_P Puntero = (PGM_P)&Device_Descriptor;
	char buffer = EP0_SIZE;
	char bytes_to_send = pgm_read_byte(Puntero);
	char temp = Paquete->wLength[0];

	if (Usb_Estado == USB_STATE_DEFAULT) temp = 8;

	if ( bytes_to_send > temp) bytes_to_send = temp;

	while (bytes_to_send)
	{
		if (buffer)
		{   //todavia puedo llenar el buffer
			UEDATX = pgm_read_byte(Puntero);
			Puntero++;
			buffer--;
			bytes_to_send--;
		}
		else
		{
			// el buffer deber�a estar lleno
			// indico que ya esta la informacion para enviar
			BufferInListo();
			// espero que me habiliten para escribir
			while (IsTransmitReady()==false);
			buffer = EP0_SIZE;
		}
	}
	
	BufferInListo(); //vacio el buffer
	while (IsRecivedDone()==false) if (IsTransmitReady()==true) BufferInListo();
	BufferOutListo();
	return;
}




void send_config_descriptor(t_SetupPck* Paquete)
{
	// ATENCION   !!!!!!!!!    WARNING
	// SOLO esta implementado para configuracion unica
	PGM_P Puntero = (PGM_P)&Config_1_Descriptor;

	// el tama�o total de la configuracion esta en el en el wTotalLenght
	// pero solo leo el byte bajo, si es  descriptor es mayor de 255
	// esto no va a funcionar
	char bytes_to_send = pgm_read_byte(Puntero+2);

	t_Interface_Descriptor* PuntI = (t_Interface_Descriptor*)pgm_read_word(Puntero+9); // = (t_Interface_Descriptor*)pgm_read_word(PuntC->next_IDescriptor);
	char buffer = EP0_SIZE;
	char size_ds = pgm_read_byte(Puntero);
	bool sending_IF = false;

	char temp = Paquete->wLength[0];

	if (bytes_to_send > temp) bytes_to_send = temp;

	// al comenzar 'size' tiene el tama�o del descriptor de configuracion
	while (bytes_to_send)// bytes_to_send!=0
	{
		if (size_ds==0)
		{
			if (sending_IF == false)
			{
				Puntero = (PGM_P)PuntI;
//if (Puntero == 0) ERRORMAC3(1,2,3); //implicaria que no hay mas interfases pero en realidad el programa deberia haber salido porque no habria mas bytes to send
				size_ds = pgm_read_byte(Puntero);
				sending_IF = true;
			}
			else
			{
				//cargar endpoint
				Puntero = (PGM_P)pgm_read_word(Puntero);
				if(Puntero==0) sending_IF = false;
				else size_ds = pgm_read_byte(Puntero);
			}
		}
		else
		{
			if (buffer) // buffer!=0
			{   //todavia puedo llenar el buffer
				UEDATX = pgm_read_byte(Puntero);
				Puntero++;
				buffer--;
				bytes_to_send--;
				size_ds--;
			}
			else
			{
				// el buffer deber�a estar lleno
				// indico que ya esta la informacion para enviar
				BufferInListo();
				while (IsTransmitReady()==false);
				buffer = EP0_SIZE;
			}
		}
	}
	
	BufferInListo(); //vacio el buffer
	while (IsRecivedDone()==false) if (IsTransmitReady()==true) BufferInListo();
	BufferOutListo();
	return;
}




void send_string_descriptor(t_SetupPck* Paquete)
{
	PGM_P Puntero = (PGM_P)pgm_read_word((PGM_P)&Strings[(int)Paquete->wValue[0]]);
	char buffer = EP0_SIZE;

	char bytes_to_send = pgm_read_byte(Puntero);
	char temp = Paquete->wLength[0];

	if ( bytes_to_send > temp) bytes_to_send = temp;

	while (bytes_to_send)
	{
		if (buffer)
		{   //todavia puedo llenar el buffer
			UEDATX = pgm_read_byte(Puntero);
			Puntero++;
			buffer--;
			bytes_to_send--;
		}
		else
		{
			// el buffer deber�a estar lleno
			// indico que ya esta la informacion para enviar
			BufferInListo();
			// espero que me habiliten para escribir
			while (IsTransmitReady()==false);
			buffer = EP0_SIZE;
		}
	}
	
	BufferInListo(); //vacio el buffer
	while (IsRecivedDone()==false) if (IsTransmitReady()==true) BufferInListo();
	BufferOutListo();
	return;
}




void procesar_STP_pck(t_SetupPck* Paquete)
{
	switch(Paquete->bmRequestType)
	{
	case RQ_DEVICE0:
		switch (Paquete->bRequest)
		{
		case RQ_D_SET_ADDRESS:
			if (Usb_Estado == USB_STATE_DEFAULT)
			{
				UDADDR = ((Paquete->wValue[0]) & 0x7F);

// comprobamos que la operacion es Host to function
//if (IsBitSet(UESTA1X,CTRLDIR)==true) ERRORMAC2(2,1);

				//segun la hoja de datos, siempre el primer packete IN
				// se responde con un NAK
				while ( IsBitSet(UEINTX,NAKINI) == false );
				ClearBit(UEINTX,NAKINI);
				BufferInListo();
				while ( IsTransmitReady() == false );

				SetBit(UDADDR,ADDEN);
				Usb_Estado = USB_STATE_ADDRESSED;
			}
			else ERRORMAC3(3,3,3);
			break;

		case RQ_D_SET_CONFIGURATION:
			if ( (Usb_Estado == USB_STATE_ADDRESSED) ) //| (Usb_Estado == USB_STATE_CONFIGURED) )
			{	
				if (Paquete->wValue[0]==1)
				{
// comprobamos que la operacion es Host to function
//if (IsBitSet(UESTA1X,CTRLDIR)==true) ERRORMAC2(2,1);

					//Ojo que al configurar los EP1 y 2 estoy deseleccionado
					// el enpoint 0, por eso es muy importante la tercera linea
					if (configurar_EP1()==ERROR) ERRORMACEND(6);
					if (configurar_EP2()==ERROR) ERRORMACEND(7);
					SeleccionarEndpoint(EndP0);
					// No hay data stage

					while ( IsBitSet(UEINTX,NAKINI) == false );
					ClearBit(UEINTX,NAKINI);
					BufferInListo();
					while ( IsTransmitReady() == false );

					Usb_Estado = USB_STATE_CONFIGURED;
					CPU_Estado = STANDBY;
				}
				else ERRORMAC3(2,1,2);
			}
			else if (Usb_Estado == USB_STATE_CONFIGURED)
			{
			// Resetear Endpoint 1 y 2

				while ( IsBitSet(UEINTX,NAKINI) == false );
				ClearBit(UEINTX,NAKINI);
				BufferInListo();
				while ( IsTransmitReady() == false );

			}
			else ERRORMAC3(1,2,3);
			break;

		case RQ_D_CLEAR_FEATURE:
ERRORMAC3(2,1,3);
			break;

		case RQ_D_SET_FEATURE:
ERRORMAC3(2,3,1);
			break;

		case RQ_D_SET_DESCRIPTOR:
		default:
ERRORMAC3(1,2,3);
			break;
		}
		break;

	case RQ_DEVICE1:
		switch (Paquete->bRequest)
		{
		case RQ_D_GET_DESCRIPTOR:
			// en el byte alto viene el tipo de descriptor requerido
			// y en el byte bajo viene el indice (config o string)
			if (Paquete->wValue[1] == DT_DEVICE) 
			{
//EL SIGUIENTE IF SE PUEDE SACAR
				if (Usb_Estado==USB_STATE_ADDRESSED)
				{
//if(Paquete->wLength[0] == 18); else ERRORMAC1(Paquete->wLength[0]);

					send_device_descriptor(Paquete);
					//mas abajo se borran los bits de NAK's

				}
				else
				{	

					send_device_descriptor(Paquete);
					//mas abajo se borran los bits de NAK's

				}
			}
			else if (Paquete->wValue[1] == DT_CONFIG) 
			{
				if ( (Usb_Estado == USB_STATE_ADDRESSED) | (Usb_Estado == USB_STATE_CONFIGURED) )
				{
					send_config_descriptor(Paquete);
					//mas abajo se borran los bits de NAK's
				}
				else ERRORMAC1(7);
			}
			else if (Paquete->wValue[1] == DT_STRING)
			{
				if ( (Usb_Estado == USB_STATE_ADDRESSED) | (Usb_Estado == USB_STATE_CONFIGURED) )
				{

					send_string_descriptor(Paquete);

					//mas abajo se borran los bits de NAK's
				}
				else ERRORMAC1(8);
			}
			else if (Paquete->wValue[1] == DT_INTERF)
			{
				ERRORMAC2(3,5);
			}
			else if (Paquete->wValue[1] == DT_ENDPOINT)
			{
				ERRORMAC2(3,4);
			}
			else 
			{

				//Me esta pidiendo un descriptor que no tengo
				// devolver Request error ??????
				// esto es porque quiero implementarlo como 0200
				ERRORMAC2(3,6);

			}

			//En el envio de algun descriptor siempre hay algun NAK
			ClearBit(UEINTX,NAKOUTI);
			ClearBit(UEINTX,NAKINI);

			break;

		case RQ_D_GET_STATUS:
ERRORMAC3(1,3,2);
			break;

		case RQ_D_GET_CONFIGURATION:
ERRORMAC3(2,4,1);
			break;

		default:
			//raro
ERRORMAC3(3,1,2);
			break;
		}
		break;
	default:
		//caso raro error
ERRORMAC3(3,5,1);
		break;
	}
}

bool GLOBAL1 = false;
char GLOBAL2 = 0;
// en teoria el ,ISR_BLOCK es lo mismo si esto o si no esta
ISR(USB_COM_vect,ISR_BLOCK)
{
	// al usar una variable (temp...) el codigo assembler queda m�s chico
	// ya que no vuelve a cargar el valor de UEINT antes de cada comparacion
	// comprobar analizando el codigo assembler al cambiar test por UEINT
	// en las comparaciones
	char Temp_EPN = UEINT;
	char Temp_INT;

	// identificar Endpoint que genero la interrupcion
	if (IsBitSet(Temp_EPN,EPINT0))
	{
		SeleccionarEndpoint(EndP0);

		//identificar el tipo de interrupcion
		Temp_INT = UEINTX;

		if (Temp_INT & (1<<RXSTPI))
		{
			t_SetupPck  Paquete;
			recuperar_STP_pck(&Paquete);

			// borro el bit para generar el handshake confirmando
			// la recepcion del paquete
			// (en realidad creo que el paquete ya esta confimado, revisar)
			ClearBit(UEINTX,RXSTPI);
			procesar_STP_pck(&Paquete);	
			
		}
		//NO ESTA IMPLEMENTADO NINGUN OTRO TIPO DE INTERRUPCION
		else ERRORMACEND(4);
/*		else if (Temp_INT & (1<<RXOUTI))
		{
		}
		else if (Temp_INT & (1<<TXINI))
		{
		}
		else if (Temp_INT & (1<<RWAL))
		{
		}
		else if (Temp_INT & (1<<FIFOCON))
		{
		}
		else if (Temp_INT & (1<<NAKINI))
		{
		}
		else if (Temp_INT & (1<<NAKOUTI))
		{
		}
		else if (Temp_INT & (1<<STALLEDI))
		{
		}
*/
	}
	else if (IsBitSet(Temp_EPN,EPINT1))
	{
		SeleccionarEndpoint(EndP1);
	
		//identificar el tipo de interrupcion
		Temp_INT = UEINTX;

		if (Temp_INT & (1<<RXSTPI))
		{
			ERRORMAC2(3,3);
		}
		else if (Temp_INT & (1<<RXOUTI))
		{
			char ByteRecibido;
//LedRojoToggle();
			// Atiendo la interrupcion
			ClearBit(UEINTX,RXOUTI);

			//Levanto el primer byte recibido
			ByteRecibido = UEDATX;
//DebugV(ByteRecibido);
//DebugR(CPU_Estado);
			switch(ByteRecibido)
			{
			case SETEAR_IMAGEN_0:
				if (CPU_Estado == STANDBY)
				{
					SeleccionarImagen(IMAG0);
				}
				break;
			case SETEAR_IMAGEN_1:
				if (CPU_Estado == STANDBY)
				{
					SeleccionarImagen(IMAG1);
//LedVerdeToggle();
				}
				break;
			case SETEAR_IMAGEN_2:
				if (CPU_Estado == STANDBY)
				{
					SeleccionarImagen(IMAG2);
				}
				break;
			case SETEAR_IMAGEN_3:
				if (CPU_Estado == STANDBY)
				{
					SeleccionarImagen(IMAG3);
				}
				break;
			case SETEAR_MODO_INV_FRAME:
				if (CPU_Estado == STANDBY)
				{
					ModoINV(MODO_INV_FRAME);
				}
				break;
			case SETEAR_MODO_INV_PIXEL:
				if (CPU_Estado == STANDBY)
				{
					ModoINV(MODO_INV_PIXEL);
				}
				break;
			case SETEAR_MODO_INV_COLUMN:
				if (CPU_Estado == STANDBY)
				{
					ModoINV(MODO_INV_COLUMN);
				}
				break;
			case SETEAR_MODO_INV_ROW:
				if (CPU_Estado == STANDBY)
				{
					ModoINV(MODO_INV_ROW);
				}
				break;
			case CARGAR_IMAGEN:
				if (CPU_Estado == STANDBY)
				{
					LedRojoOff();
					ControladoraWakeup();  // en realidad esto seria si el modo del CPU es DURMIENDO
					SetGlobalClear();
					SetModoLoad();

					CfgDataEscritura();
					MemOutputDisable();

//					SetPDRDisplay();

					ReleaseGlobalClear();
					CPU_Estado = RECIBIENDO;
				}
				break;
			case COMPROBAR_IMAGEN:
				if ((CPU_Estado == STANDBY) || (CPU_Estado == RECIBIENDO))
				{
					LedRojoOff();
					ControladoraWakeup();  // en realidad esto seria si el modo del CPU es DURMIENDO
					SetGlobalClear();
					SetModoLoad();

					CfgDataLectura();
					MemOutputEnable();

//					SetPDRDisplay();

					ReleaseGlobalClear();
					CPU_Estado = COMPROBANDO;
				}
				break;
			case MOSTRAR_IMAGEN:
//				if ((CPU_Estado == STANDBY)|(CPU_Estado == RECIBIENDO)
				{
LedVerdeOn();
					ControladoraWakeup();  // en realidad esto seria si el modo del CPU es DURMIENDO
					SetGlobalClear();
					SetModoDisplay();

					CfgDataLectura();
					MemOutputEnable();

					SetPDRDisplay();

					ReleaseGlobalClear();
					CPU_Estado = STANDBY; // aca deber�a ponerlo a dormir
				}
				break;
			case APAGAR:
				ClearPDRDisplay();
				ControladoraSleep();
				CPU_Estado = DURMIENDO;
				break;
			default:
				break;
			}

			//descarto los bits restantes
//			while(IsBitSet(UEINTX,RWAL)) ByteRecibido = UEDATX;

			ClearBit(UEINTX,NAKOUTI);
			ClearBit(UEINTX,FIFOCON);
		}
		//NO ESTA IMPLEMENTADO NINGUN OTRO TIPO DE INTERRUPCION
		else ERRORMACEND(9);
/*		else if (Temp_INT & (1<<TXINI))
		{
		}
		else if (Temp_INT & (1<<RWAL))
		{
		}
		else if (Temp_INT & (1<<FIFOCON))
		{
		}
		else if (Temp_INT & (1<<NAKINI))
		{
		}
		else if (Temp_INT & (1<<NAKOUTI))
		{
		}
		else if (Temp_INT & (1<<STALLEDI))
		{
		}
*/
	}
	else if (IsBitSet(Temp_EPN,EPINT2))
	{
		SeleccionarEndpoint(EndP2);

		//identificar el tipo de interrupcion
		Temp_INT = UEINTX;

		if (Temp_INT & (1<<RXSTPI))
		{
			ERRORMAC2(2,3);
		}
		else if (Temp_INT & (1<<RXOUTI))
		{
			char ByteRecibido;

			// Atiendo la interrupcion
			ClearBit(UEINTX,RXOUTI);

			//Levanto el primer byte recibido
			if (CPU_Estado == RECIBIENDO)
			{
				while(IsBitSet(UEINTX,RWAL))
				{	
					//avanzo
					PulsoFreeClock();
					//pongo dato en puerto
					ByteRecibido = UEDATX;
					EscribirData(ByteRecibido);
					//Habilito escritura
					MemWriteEnable();
LedVerdeToggle();

					//deshabilito escritura
					MemWriteDisable();
				}
			}
			else if (CPU_Estado == COMPROBANDO)
			{
				char ByteLeido;
				while(IsBitSet(UEINTX,RWAL))
				{	
					PulsoFreeClock();
					//avanzo
					ByteRecibido = UEDATX;
					//Tomo Byte de la memoria
					LeerData(ByteLeido);

					//Comparo los datos
					if (ByteLeido==ByteRecibido) LedVerdeToggle();
					else LedRojoOn();
				}
			}
			else ERRORMACEND(5);
			//descarto los bits restantes
//			while(IsBitSet(UEINTX,RWAL)) ByteRecibido = UEDATX;

			ClearBit(UEINTX,NAKOUTI);
			ClearBit(UEINTX,FIFOCON);
		}
		else ERRORMACEND(12);
/*		else if (Temp_INT & (1<<TXINI))
		{
		}
		else if (Temp_INT & (1<<RWAL))
		{
		}
		else if (Temp_INT & (1<<FIFOCON))
		{
		}
		else if (Temp_INT & (1<<NAKINI))
		{
		}
		else if (Temp_INT & (1<<NAKOUTI))
		{
		}
		else if (Temp_INT & (1<<STALLEDI))
		{
		}
*/
	}
/*	else if (IsBitSet(Temp_EPN,EPINT3))
	{
		SeleccionarEndpoint(EndP3);

		//identificar el tipo de interrupcion
		Temp_INT = UEINTX;

		if (Temp_INT & (1<<RXSTPI))
		{
		}
		else if (Temp_INT & (1<<RXOUTI))
		{
		}
		else if (Temp_INT & (1<<TXINI))
		{
		}
		else if (Temp_INT & (1<<RWAL))
		{
		}
		else if (Temp_INT & (1<<FIFOCON))
		{
		}
		else if (Temp_INT & (1<<NAKINI))
		{
		}
		else if (Temp_INT & (1<<NAKOUTI))
		{
		}
		else if (Temp_INT & (1<<STALLEDI))
		{
		}
		else ERRORMAC3(3,2,4);
	}
	else if (IsBitSet(Temp_EPN,EPINT4))
	{
		SeleccionarEndpoint(EndP4);

		//identificar el tipo de interrupcion
		Temp_INT = UEINTX;

		if (Temp_INT & (1<<RXSTPI))
		{
		}
		else if (Temp_INT & (1<<RXOUTI))
		{
		}
		else if (Temp_INT & (1<<TXINI))
		{
		}
		else if (Temp_INT & (1<<RWAL))
		{
		}
		else if (Temp_INT & (1<<FIFOCON))
		{
		}
		else if (Temp_INT & (1<<NAKINI))
		{
		}
		else if (Temp_INT & (1<<NAKOUTI))
		{
		}
		else if (Temp_INT & (1<<STALLEDI))
		{
		}
		else ERRORMAC3(3,2,5);
	}
*/
	//ERROR: Se genero una interrupcion de un Endpoint no esta implementado
	else ERRORMACEND(2);
	return;
}




// en teoria el ,ISR_BLOCK es lo mismo si esta o si no esta
ISR(USB_GEN_vect,ISR_BLOCK)
{
	// al usar una variable (temp...) el codigo assembler queda m�s chico
	// ya que no vuelve a cargar el valor de UDINT antes de cada comparacion
	// comprobar analizando el codigo assembler al cambiar test por UDINT
	// en las comparaciones
	char Temp_UDINT = UDINT;

	if (IsBitSet(Temp_UDINT,UPRSMI))
	{
		///  TODAVIA NO IMPLEMENTADA
		ClearBit(UDINT,UPRSMI); // borra el flag de interrupcion
	}
	else if (IsBitSet(Temp_UDINT,EORSMI))
	{
		///  TODAVIA NO IMPLEMENTADA
		ClearBit(UDINT,EORSMI); // borra el flag de interrupcion
	}
	else if (IsBitSet(Temp_UDINT,WAKEUPI))
	{
		///  TODAVIA NO IMPLEMENTADA
		ClearBit(UDINT,WAKEUPI);// borra el flag de interrupcion
	}
	else if (IsBitSet(Temp_UDINT,EORSTI))
	{
		if(configurar_USB()==ERROR) ERRORMAC2(2,2);

		Usb_Estado = USB_STATE_DEFAULT;
		CPU_Estado = STANDBY;
		ClearBit(UDINT,EORSTI); // borra el flag de interrupcion
	}
	else if (IsBitSet(Temp_UDINT,SOFI))
	{
		///  TODAVIA NO IMPLEMENTADA
		if (UDMFN & (1<<FNCERR))
		{
		}
		else
		{
		}
		ClearBit(UDINT,SOFI); // borra el flag de interrupcion
	}
	else if (IsBitSet(Temp_UDINT,UPRSMI))
	{
		///  TODAVIA NO IMPLEMENTADA
		ClearBit(UDINT,UPRSMI); // borra el flag de interrupcion
	}
	return;
}



bool configurar_USB(void)
{
	SetBit(USBCON,USBE);
	ClearBit(USBCON,FRZCLK);

	UDIEN = UDIEN_MASK_INI;

	// Configuracion de Endpoint 0
	if (configurar_EP0()==ERROR) return ERROR;

	Usb_Estado = USB_STATE_POWERED;

#ifdef __DEBUGGING__
procesar_STP_pck(&PaqueteTest);
#endif

	return OK;
}
