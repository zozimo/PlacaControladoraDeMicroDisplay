#ifndef __DESCRIPTORES__
#define __DESCRIPTORES__

#include "Usb_drv.h"

// -- Tipos de estructuras

typedef struct _t_Device_Descriptor
{
	prog_char	bLength;
	prog_char	bDescriptorType;
	prog_char	bcdUSB[2];
	prog_char	bDeviceClass;
	prog_char	bDeviceSubClass;
	prog_char	bDeviceProtocol;
	prog_char	bMaxPacketsize0;
	prog_char	idVendor[2];  //el i[0] es el low, tener en cuenta al grabar
	prog_char	idProduct[2];
	prog_char	bcdDevice[2];
	prog_char	iManufacter;
	prog_char	iProduct;
	prog_char	iSerialNumber;
	prog_char	bNumConfigurations;
} PROGMEM t_Device_Descriptor;


typedef struct _t_Endpoint_Descriptor 
{
	prog_char bLength;
	prog_char bDescriptorType;
	prog_char bEndPointAddress; 
	prog_char bmAttibutes;
	prog_char wMaxPacketSize[2]; //el w[0] es el low, tener en cuenta al grabar
	prog_char bInterval;  //todavia no entiendo bien que es
	struct _t_Endpoint_Descriptor* PROGMEM next_EDescriptor;
} PROGMEM t_Endpoint_Descriptor;


typedef struct  _t_Interface_Descriptor
{
	prog_char bLength;
	prog_char bDescriptorType;
	prog_char bInterfaceNumber;
	prog_char bAlternateSetting;
	prog_char bNumEndpoints;
	prog_char bInterfaceClass;
	prog_char bInterfaceSubClass;
	prog_char bInterfaceProtocol;
	prog_char iInterface;
	t_Endpoint_Descriptor* next_EDescriptor;
	struct _t_Interface_Descriptor* PROGMEM next_IDescriptor;
} PROGMEM t_Interface_Descriptor;


typedef struct  _t_Config_Descriptor
{
	prog_char bLength;
	prog_char bDescriptorType;
	prog_char wTotalLength[2]; //el w[0] es el low, tener en cuenta al grabar
	prog_char bNumberInterfaces;
	prog_char bConfigurationValue;
	prog_char iConfiguracion;
	prog_char bmAttributes;
	prog_char bMaxPower;
	t_Interface_Descriptor* next_IDescriptor;
} PROGMEM t_Config_Descriptor;


// El tama�o del descriptor es el tama�o del string mas 2 bytes
// correspondientes a los dos primeros campos.
// Los caracteres Unicode son de 16bits (2bytes).
// El string tiene un caracter NULL al final que no es necesario
// por lo cual el string es 2 bytes mas grande de lo que debemos enviar
// Por lo tanto para todos los string
// bLength = ( sizeof(STRINGX) - 2 ) + 2
// Para el String0 solamente hay numeros de LANGID, entonces no va el (-2)
// bLength = ( sizeof(STRING0) ) + 2
typedef struct
{
	prog_char bLength;
	prog_char bDescriptorType;
	prog_int16_t bString[];
} PROGMEM t_String_Descriptor;


// ------------


// Defines necesarios para los descriptores

// Tama�os estandar
#define SIZE_DEV_DS	sizeof(t_Device_Descriptor)
#define SIZE_EP_DS ( sizeof(t_Endpoint_Descriptor) - sizeof(t_Endpoint_Descriptor*) )
#define SIZE_ITF_DS ( ( sizeof(t_Interface_Descriptor) - sizeof(t_Endpoint_Descriptor*) ) - sizeof(t_Interface_Descriptor*) )
#define SIZE_CONF_DS	( sizeof(t_Config_Descriptor) - sizeof(t_Interface_Descriptor *) )
// ----


// Defines particulares para esta implementacion
#define CF_N		1
#define IF_N_C1		1
#define EP_N_C1_I0	2

#define SIZE_CONF_DS0 	( SIZE_CONF_DS + (IF_N_C1 * SIZE_ITF_DS) + (EP_N_C1_I0 * SIZE_EP_DS) )


#define EP0_SIZE	8        // 8   16   32    64
#define EP1_SIZE	8        // 8   16   32    64
#define EP2_SIZE	64        // 8   16   32    64



#define	USB_VER		0x0110  //BCD
#define	VENDOR_ID	0x03EB
#define	PRODUCT_ID	0x4568
#define	DEVICE_REV	0x0011  //BCD

#define MANUFC_STR_IND	1
#define	PRODUCT_STR_IND	2
#define	SERIAL_STR_IND	3

#define	STRING1			L"Ariel Burman - LAO - 2009"
#define STRING2			L"Controlador Microdisplay Kopin"
#define	STRING3			L"3001001004"

#define EPOUT_M		0x00
#define EPIN_M		0x80
#define EPNUM1_M	1
#define EPNUM2_M	2


#define EPCT_M      0b00000000
#define EPIS_M		0b00000001
#define EPBK_M      0b00000010
#define EPIT_M		0b00000011


#define EPBLKRET_M	3



#define INTF0_CLASS			0xFF
#define INTF0_SUBCL			0x00
#define INTF0_PROT			0x00
#define	INTF0_STRING_IND	5

#define STRING5				L"Interfase Controlador"

#define BUS_POW_M			0b10000000
#define SELF_POW_M			0b01000000
#define RWKUP_NO_SUPP_M		0
#define RWKUP_SUPP_M		0b00100000
#define CFPOWER				100  //poner en mA, el compilador despues divide por 2
#define CONFIG1_STRING_IND	4

#define	STRING4		L"Configuracion Self Powered"	

#define	LANGOPT		1
#define	wLANGID		{0x0409}  // 0x0409-(English USA)  0x2c0a-(Spanish - Argent)
#define STRING0		wLANGID


// -------------


// Descriptores particulares para esta implementacion
// A excepcion del Device Descriptor, los otros deben
// definirse comenzando desde el �ltimo, ya que cada
// descriptor hace referencia al siguiente
t_Device_Descriptor Device_Descriptor  =
{
.bLength			=	SIZE_DEV_DS,  //deberia ser 18 o 0x12
.bDescriptorType	=	DT_DEVICE,
.bcdUSB				=	{LOW(USB_VER),HIGH(USB_VER)},
.bDeviceClass		=	0,
.bDeviceSubClass	=	0,
.bDeviceProtocol	=	0,
.bMaxPacketsize0	=	EP0_SIZE,
.idVendor			=	{LOW(VENDOR_ID),HIGH(VENDOR_ID)},
.idProduct			=	{LOW(PRODUCT_ID),HIGH(PRODUCT_ID)},
.bcdDevice			=	{LOW(DEVICE_REV),HIGH(DEVICE_REV)},
.iManufacter		=	MANUFC_STR_IND,
.iProduct			=	PRODUCT_STR_IND,
.iSerialNumber		=	SERIAL_STR_IND,
.bNumConfigurations	=	CF_N
};

// Endpoint 2 Interfase 0 Configuracion1
// OUT BULK 64 bytes
t_Endpoint_Descriptor Endpoint2_I0_C1_Descritpor =
{
.bLength			=	SIZE_EP_DS,
.bDescriptorType	=	DT_ENDPOINT,
.bEndPointAddress	=	(EPOUT_M | EPNUM2_M),   //
.bmAttibutes		=	EPBK_M,   //
.wMaxPacketSize		=	{LOW(EP2_SIZE),HIGH(EP2_SIZE)},  //
.bInterval			=	EPBLKRET_M,            //
.next_EDescriptor	=	(t_Endpoint_Descriptor*)0
};

// Endpoint 1 Interfase 0 Configuracion1
// OUT BULK 8 bytes
t_Endpoint_Descriptor Endpoint1_I0_C1_Descritpor  =
{
.bLength			=	SIZE_EP_DS,
.bDescriptorType	=	DT_ENDPOINT,
.bEndPointAddress	=	(EPOUT_M | EPNUM1_M),   //poner mascara
.bmAttibutes		=	EPBK_M,   //poner mascara
.wMaxPacketSize		=	{LOW(EP1_SIZE),HIGH(EP1_SIZE)},  //poner mascara
.bInterval			=	EPBLKRET_M,            //poner mascara
.next_EDescriptor	=	(t_Endpoint_Descriptor*)&Endpoint2_I0_C1_Descritpor,
};

// Interfase 0 Configuracion1
// 
t_Interface_Descriptor Interface0_C1_Descriptor =
{
.bLength			=	SIZE_ITF_DS,
.bDescriptorType	=	DT_INTERF,
.bInterfaceNumber	=	0,     //poner mascara
.bAlternateSetting	=	0,     //poner mascara
.bNumEndpoints		=	EP_N_C1_I0,     //poner mascara
.bInterfaceClass	=	INTF0_CLASS,  //poner mascara
.bInterfaceSubClass	=	INTF0_SUBCL,  //poner mascara
.bInterfaceProtocol	=	INTF0_PROT,  //poner mascara
.iInterface			=	INTF0_STRING_IND,     //poner mascara
.next_EDescriptor	=	(t_Endpoint_Descriptor*)&Endpoint1_I0_C1_Descritpor,
.next_IDescriptor	=	(t_Interface_Descriptor*)0
};


t_Config_Descriptor Config_1_Descriptor =
{
.bLength			 =	SIZE_CONF_DS,
.bDescriptorType	 =	DT_CONFIG,
.wTotalLength		 =	{LOW(SIZE_CONF_DS0),HIGH(SIZE_CONF_DS0)},
.bNumberInterfaces	 =	IF_N_C1,
.bConfigurationValue =	1, // valor usado para identificar la configuracion
.iConfiguracion		 =	CONFIG1_STRING_IND,
.bmAttributes		 =	(SELF_POW_M|RWKUP_NO_SUPP_M),
.bMaxPower			 =	(CFPOWER>>1),
.next_IDescriptor	 =	(t_Interface_Descriptor*)&Interface0_C1_Descriptor,
};


t_String_Descriptor String_Descriptor_0 =
{
.bLength 			= 	sizeof(LANGOPT)+2,  // ver definicion typedef
.bDescriptorType 	= 	DT_STRING,
.bString			=	STRING0
};


t_String_Descriptor String_Descriptor_1 =
{
.bLength 			= 	sizeof(STRING1), // ver definicion typedef
.bDescriptorType 	= 	DT_STRING,
.bString			=	STRING1
};

t_String_Descriptor String_Descriptor_2 =
{
.bLength 			= 	sizeof(STRING2), // ver definicion typedef
.bDescriptorType 	= 	DT_STRING,
.bString			=	STRING2
};


t_String_Descriptor String_Descriptor_3 =
{
.bLength 			= 	sizeof(STRING3), // ver definicion typedef
.bDescriptorType 	= 	DT_STRING,
.bString			=	STRING3
};

t_String_Descriptor String_Descriptor_4 =
{
.bLength 			= 	sizeof(STRING4), // ver definicion typedef
.bDescriptorType 	= 	DT_STRING,
.bString			=	STRING4
};

t_String_Descriptor String_Descriptor_5 =
{
.bLength 			= 	sizeof(STRING5), // ver definicion typedef
.bDescriptorType 	= 	DT_STRING,
.bString			=	STRING5
};

t_String_Descriptor* Strings[] PROGMEM =
{	
	(t_String_Descriptor*)&String_Descriptor_0,
	(t_String_Descriptor*)&String_Descriptor_1,
	(t_String_Descriptor*)&String_Descriptor_2,
	(t_String_Descriptor*)&String_Descriptor_3,
	(t_String_Descriptor*)&String_Descriptor_4,
	(t_String_Descriptor*)&String_Descriptor_5,
};

#endif
