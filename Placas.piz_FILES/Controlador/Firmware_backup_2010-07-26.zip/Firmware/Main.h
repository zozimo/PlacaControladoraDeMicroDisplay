#ifndef __KOPINFIRMWARE__
#define __KOPINFIRMWARE__


#include <avr/io.h>
#include <avr/interrupt.h>


#include "General.h"
#include "Board.h"
#include "Usb_drv.h"


bool configuracion (void);
bool configurar_PLL (void);
void configurar_BOARD (void);


#endif
