#ifndef __GENERAL__
#define __GENERAL__

//#define __DEBUGGING__

//Las lineas de debuggin deben quedar sin indentacion
// para que luego sean mas faciles de eliminar

#ifndef F_CPU
	#define F_CPU 8000000UL
#endif
#include <util/delay.h>

#define bool	_Bool
#define true	1
#define false   0
#define OK		true
#define ERROR	false
#define Nop()	asm volatile("nop")

#define LOW(a)		(char)(a & 0x00ff)
#define	HIGH(a)		(char)(a >> 8)

#define SetBit(Byte,Bit)	 (Byte |= (1<<Bit))
#define	ClearBit(Byte,Bit)	 (Byte &= (~(1<<Bit)))
#define IsBitSet(Byte,Bit)	 ( (Byte & (1<<Bit)) ? true : false )
#define IsBitClear(Byte,Bit) ( (Byte & (1<<Bit)) ? false : true )


#define IsPllLock()       ( IsBitSet(PLLCSR,PLOCK) ? OK : ERROR )





char	DatoFIRST;
char 	CPU_Estado;

// ESTADOS CPU   Varieble CPU_Estado
#define DURMIENDO		0
#define STANDBY			1	//Esperando comando
#define RECIBIENDO		2
#define COMPROBANDO		3

// COMANDOS CPU_PC
#define APAGAR					4
#define SETEAR_IMAGEN_0			5
#define SETEAR_IMAGEN_1			6
#define SETEAR_IMAGEN_2			7
#define SETEAR_IMAGEN_3			8
#define SETEAR_MODO_INV_FRAME	9
#define SETEAR_MODO_INV_PIXEL	10
#define SETEAR_MODO_INV_COLUMN	11
#define SETEAR_MODO_INV_ROW		12
#define CARGAR_IMAGEN			13
#define COMPROBAR_IMAGEN		14
#define MOSTRAR_IMAGEN			15



/// herramienta para testear el contenido de algunas variables
/// borrar del dise�o final para asegurar que no quede ninguna
/// de debugging

#include "Board.h"

#define DebugV(a)      {int temp; temp = a; pulsos_verdes(temp);}
#define DebugR(a)      {int temp; temp = a; pulsos_rojos(temp);}


//implementadas en Test.c pero deber�an ir en otro archivo
void pulsos_rojos (char pulsos);
void pulsos_verdes (char pulsos);

#define ERRORMAC1(a) {pulsos_verdes(a);pulsos_rojos(a);cli();LedVerdeOn();LedRojoOn();while(1);}
#define ERRORMAC2(a,b) {pulsos_verdes(a);pulsos_rojos(a);pulsos_verdes(b);pulsos_rojos(b);cli();LedVerdeOn();LedRojoOn();while(1);}
#define ERRORMAC3(a,b,c) {pulsos_verdes(a);pulsos_rojos(a);pulsos_verdes(b);pulsos_rojos(b);pulsos_verdes(c);pulsos_rojos(c);cli();LedVerdeOn();LedRojoOn();while(1);}
#define ERRORMACEND(a)	{pulsos_verdes(a);pulsos_rojos(a);cli();LedVerdeOn();LedRojoOn();while(1);}



#endif
