#include "Main.h"

#define DATOTEST	0xF4

void pulsos_rojos (char pulsos)
{
	while (pulsos>0)
	{
		LedRojoOff();
		_delay_ms(250);
		LedRojoOn();
		_delay_ms(250);
		--pulsos;
	}
	LedRojoOff();
	return;
}

void pulsos_verdes (char pulsos)
{
	while (pulsos>0)
	{
		LedVerdeOff();
		_delay_ms(250);
		LedVerdeOn();
		_delay_ms(250);
		--pulsos;
	}
	LedVerdeOff();
	return;
}



int main (void)
{
	if (configuracion()==ERROR) ERRORMAC2(10,10);

/*	ControladoraWakeup();
	SetGlobalClear();
	SetModoLoad();

	CfgDataEscritura();
	MemOutputDisable();

	ReleaseGlobalClear();

	char DatosPatron[] = {6, 8, 12, 14, 15, 74, 125, 32, 5, 1, 33, 45, 12};
//	char DatosPatron[] = {0x08,0x06,0x0D,0x10,0x45,0x89,0xAB,0x23,0x42,0x75,0x9C,0xFE,0xCF,0xDE,0xB3,0x00};
//	char DatosPatron[] = {0xFF,0xFF,0xF1,0xF0,0xF2,0x2F,0x3F,0x44,0x33,0x21,0xFF,0xFF,0xFF,0xFF,0xFF};
//	char DatosPatron[] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
//	char DatosPatron[] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	char Tempo;
	int i = 0;

	for (i=0 ; i<sizeof(DatosPatron) ; i++)
	{
		PulsoFreeClock();		
		EscribirData(DatosPatron[i]);
		MemWriteEnable();
		MemWriteDisable();
	}



	SetGlobalClear();
	ReleaseGlobalClear();

	CfgDataLectura();
	MemOutputEnable();
	
	for (i=0 ; i<sizeof(DatosPatron) ; i++)
	{
		PulsoFreeClock();
		LeerData(Tempo);
		if (Tempo != DatosPatron[i]) LedRojoOn();
	}
	LedVerdeOn();

*/
	while(1)
	{
	}

//	DatoFIRST=0;
//	while(1)
//	{
//if (DatoFIRST >10)
//{
//DebugV(DatoFIRST);
//_delay_ms(3000);
//}
//	}
	return 0;
}


bool configuracion (void)
{
	LedVerdeCfg();
	LedRojoCfg();
	LedVerdeOff();
	LedRojoOff();

	configurar_BOARD();
	if (configurar_PLL()==ERROR) return ERROR;
	if (configurar_USB()==ERROR) return ERROR;



	CPU_Estado = DURMIENDO;
	sei();   // Habilitar interrupciones
	AttachUSB();
	return OK;
}

bool configurar_PLL(void)
{
	SetBit(PLLCSR,PLLE);
#ifndef __DEBUGGING__
	_delay_ms(100);
#elif
SetBit(PLLCSR,PLOCK);
Nop();
#endif
	return IsPllLock();
}


void configurar_BOARD(void)
{
	ConfigControlBits();
	SetGlobalClear();
	MemWriteDisable();
	MemOutputDisable();
	ControladoraSleep();
	SetModoLoad();
	SeleccionarImagen(IMAG0);
	ModoINV(MODO_INV_PIXEL);
	return;
}
