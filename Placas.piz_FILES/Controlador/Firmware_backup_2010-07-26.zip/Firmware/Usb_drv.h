#ifndef __USB_DRV__
#define __USB_DRV__

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>

#include "General.h"

// las funciones macro empiezan con mayuscula y no llevan espacio

////// Definiciones para microntrolador
#define SeleccionarEndpoint(a)		( UENUM = a )
#define EndP0	0
#define EndP1	1
#define EndP2	2
#define EndP3	3
#define EndP4	4

#define EPT_CONTROL			0x00 //0<<6
#define EPT_BULK			2<<6 //0x80
#define EPT_ISOCHRONOUS		1<<6 //0x40
#define EPT_INTERRUPT		3<<6 //0xC0

#define EPT_IN				0x01
#define EPT_OUT				0x00

#define EPT_SINGLE_BANK		0<<2
#define EPT_DOUBLE_BANK		0<<2

#define	EPT_SIZE_8			0<<4
#define	EPT_SIZE_16			1<<4
#define	EPT_SIZE_32			2<<4
#define	EPT_SIZE_64			3<<4


#define HabilitarEndP()    SetBit(UECONX,EPEN)
//usar despues de Seleccionar Endpoint)
#define IsEPHab()		(IsBitSet(UECONX,EPEN) ? OK : ERROR)


#define IsTransmitReady()	IsBitSet(UEINTX,TXINI)
#define BufferInListo()		ClearBit(UEINTX,TXINI)

#define IsRecivedDone()     IsBitSet(UEINTX,RXOUTI)
#define BufferOutListo()	ClearBit(UEINTX,RXOUTI)

#define AttachUSB() 	ClearBit(UDCON,DETACH)
#define DettachUSB()	SetBit(UDCON,DETACH)



// las funciones comunes empiezan en minuscula y llevan un '_' entre palabras
bool configurar_USB(void);
void test_EP0_cfg(void);





/////////////////////////////
///// Definiciones USB 2.0 STANDARD

#define RQ_DEVICE0	0x00
#define	RQ_DEVICE1 	0x80
#define RQ_DEVMASK	0xF0
#define RQ_EPMASK	0x0F

#define RQ_D_GET_STATUS			0
#define RQ_D_CLEAR_FEATURE		1
#define RQ_D_SET_FEATURE		3
#define RQ_D_SET_ADDRESS		5
#define RQ_D_GET_DESCRIPTOR		6
#define RQ_D_SET_DESCRIPTOR		7
#define RQ_D_GET_CONFIGURATION	8
#define RQ_D_SET_CONFIGURATION	9

#define RQ_D_GET_INTERFACE		10
#define RQ_D_SET_INTERFACE		11
#define RQ_D_SYNCH_FRAME		12



#define DT_DEVICE	1
#define DT_CONFIG	2
#define DT_STRING	3
#define DT_INTERF	4
#define DT_ENDPOINT	5


#define	FS_D_REMWKUP	1
#define FS_EP_HALT		0
#define FS_TEST_MODE	2

#define USB_STATE_UNDEF			0
#define USB_STATE_ATACHED		1
#define USB_STATE_POWERED		2
#define USB_STATE_DEFAULT		3
#define USB_STATE_ADDRESSED		4
#define USB_STATE_CONFIGURED	5
#define USB_STATE_SUSPENDED		6

char	Usb_Estado;
//char	Temporal;


#endif
