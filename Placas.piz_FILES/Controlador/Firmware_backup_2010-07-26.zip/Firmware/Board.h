#ifndef __BOARD__
#define __BOARD__


// Los leds en la placa controladora v1.0
// est�n configurados para prender por uno
// Las funciones para prenderlos y apagarlos son macros

#define	LED_VERDE_PORT		PORTC
#define	LED_VERDE_DDR		DDRC
#define	LED_VERDE_PIN		PINC
#define	LED_VERDE_PIN_N		4
#define	LED_ROJO_PORT		PORTC
#define LED_ROJO_DDR		DDRC
#define LED_ROJO_PIN		PINC
#define LED_ROJO_PIN_N		5

#define LedVerdeOn()		SetBit(LED_VERDE_PORT,LED_VERDE_PIN_N)
#define LedVerdeOff()		ClearBit(LED_VERDE_PORT,LED_VERDE_PIN_N)
#define LedVerdeToggle()	SetBit(LED_VERDE_PIN,LED_VERDE_PIN_N)
#define LedVerdeCfg()		SetBit(LED_VERDE_DDR,LED_VERDE_PIN_N)

#define LedRojoOn()			SetBit(LED_ROJO_PORT,LED_ROJO_PIN_N)
#define LedRojoOff()		ClearBit(LED_ROJO_PORT,LED_ROJO_PIN_N)
#define LedRojoToggle()		SetBit(LED_ROJO_PIN,LED_ROJO_PIN_N)
#define LedRojoCfg()		SetBit(LED_ROJO_DDR,LED_ROJO_PIN_N)

/////  PORT DATOS

#define DATA_PORT			PORTD
#define	DATA_PIN			PIND
#define DATA_DDR			DDRD
//#define DATA				PORTD

#define CfgDataLectura()	DATA_DDR = 0x00
#define	CfgDataEscritura()	DATA_DDR = 0xFF
#define LeerData(a)			a = DATA_PIN
#define	EscribirData(a)		DATA_PORT = a


///// PINES DE CONTROL

#define ADDRX_PORT			PORTB
#define ADDRX_DDR			DDRB
#define	ADDRX_PIN			PINB
#define	ADDR18_PIN_N		0
#define	ADDR17_PIN_N		1

#define IMAG0				0 // ( (0<<ADDR18_PIN_N)|(0<<ADDR17_PIN_N) )
#define IMAG1				1 //( (0<<ADDR18_PIN_N)|(1<<ADDR17_PIN_N) )
#define IMAG2				2 // ( (1<<ADDR18_PIN_N)|(0<<ADDR17_PIN_N) )
#define IMAG3				3 //( (1<<ADDR18_PIN_N)|(1<<ADDR17_PIN_N) )

#define SeleccionarImagen(IMAGNUM) 					\
{ 													\
	switch (IMAGNUM) 								\
	{ 												\
		case IMAG0: 								\
			ClearBit(ADDRX_PORT,ADDR18_PIN_N);		\
			ClearBit(ADDRX_PORT,ADDR17_PIN_N);		\
			break; 									\
		case IMAG1: 								\
			ClearBit(ADDRX_PORT,ADDR18_PIN_N);		\
			SetBit(ADDRX_PORT,ADDR17_PIN_N);		\
			break; 									\
		case IMAG2: 								\
			SetBit(ADDRX_PORT,ADDR18_PIN_N);		\
			ClearBit(ADDRX_PORT,ADDR17_PIN_N);		\
			break; 									\
		case IMAG3: 								\
			SetBit(ADDRX_PORT,ADDR18_PIN_N);		\
			SetBit(ADDRX_PORT,ADDR17_PIN_N);		\
			break; 									\
		default:									\
			ERRORMAC3(4,5,6);						\
	}												\
}

/////////

#define FCLK_PORT			PORTB
#define FCLK_DDR			DDRB
#define	FCLK_PIN			PINB
#define	FCLK_PIN_N			2

// revisar si el nop es necesario
//#define PulsoFreeClock()	{SetBit(FCLK_PORT,FCLK_PIN_N); Nop(); ClearBit(FCLK_PORT,FCLK_PIN_N);}
#define PulsoFreeClock()	{SetBit(FCLK_PORT,FCLK_PIN_N); Nop();Nop();Nop();Nop();Nop();ClearBit(FCLK_PORT,FCLK_PIN_N);}

#define MODOLOAD_PORT			PORTB
#define MODOLOAD_DDR			DDRB
#define	MODOLOAD_PIN			PINB
#define	MODOLOAD_PIN_N			3

#define SetModoLoad()			SetBit(MODOLOAD_PORT,MODOLOAD_PIN_N)
#define SetModoDisplay()		ClearBit(MODOLOAD_PORT,MODOLOAD_PIN_N)

/////////

#define PDR_PORT			PORTB
#define PDR_DDR				DDRB
#define	PDR_PIN				PINB
#define	PDR_PIN_N			4

#define SetPDRDisplay()		SetBit(PDR_PORT,PDR_PIN_N)
#define ClearPDRDisplay()	ClearBit(PDR_PORT,PDR_PIN_N)

/////////

#define SLEEP_PORT			PORTB
#define SLEEP_DDR			DDRB
#define	SLEEP_PIN			PINB
#define	SLEEP_PIN_N			5

#define ControladoraSleep()		SetBit(SLEEP_PORT,SLEEP_PIN_N)
#define ControladoraWakeup()	ClearBit(SLEEP_PORT,SLEEP_PIN_N)

/////////

#define OE_PORT				PORTB
#define OE_DDR				DDRB
#define	OE_PIN				PINB
#define	OE_PIN_N			6

#define MemOutputEnable()	ClearBit(OE_PORT,OE_PIN_N)
#define MemOutputDisable()	SetBit(OE_PORT,OE_PIN_N)

#define WE_PORT				PORTC
#define WE_DDR				DDRC
#define	WE_PIN				PINC
#define	WE_PIN_N			2

#define MemWriteEnable()	ClearBit(WE_PORT,WE_PIN_N)
#define MemWriteDisable()	SetBit(WE_PORT,WE_PIN_N)

/////////

#define CLR_PORT			PORTB
#define CLR_DDR				DDRB
#define	CLR_PIN				PINB
#define	CLR_PIN_N			7

#define SetGlobalClear()		SetBit(CLR_PORT,CLR_PIN_N)
#define ReleaseGlobalClear()	ClearBit(CLR_PORT,CLR_PIN_N)

/////////

#define INV_PORT			PORTC
#define INV_DDR				DDRC
#define	INV_PIN				PINC
#define	INV0_PIN_N			6
#define	INV1_PIN_N			7

#define MODO_INV_FRAME		0  
#define	MODO_INV_PIXEL		1  // Modo recomendado por fabricante INV0 = 0 ; INV1 = 1 
#define MODO_INV_COLUMN		2  
#define MODO_INV_ROW		3

//#define ModoINV(a)			INV_PORT |= (a<<6) // a entre 0 y 3
#define ModoINV(MODO)			 			\
{ 											\
	switch (MODO) 							\
	{ 										\
		case MODO_INV_FRAME: 				\
			ClearBit(INV_PORT,INV0_PIN_N);	\
			ClearBit(INV_PORT,INV1_PIN_N);	\
			break; 							\
		case MODO_INV_PIXEL: 				\
			ClearBit(INV_PORT,INV0_PIN_N);	\
			SetBit(INV_PORT,INV1_PIN_N);	\
			break; 							\
		case MODO_INV_COLUMN: 				\
			SetBit(INV_PORT,INV0_PIN_N);	\
			ClearBit(INV_PORT,INV1_PIN_N);	\
			break; 							\
		case MODO_INV_ROW: 					\
			SetBit(INV_PORT,INV0_PIN_N);	\
			SetBit(INV_PORT,INV1_PIN_N);	\
			break; 							\
		default:							\
			ERRORMAC3(4,5,7);				\
	}										\
}

/////////

// esta macro setea con menos c�digo todos los bits de control
// todos son salidas
// HAY QUE MODIFICAR SI SE CAMBIA LA UBICACION DE LOS PORT DE LOS BITS
// AHORA ES TODO EL PORTB y 3 pines del PORTC
#define	ConfigControlBits()	{DDRB = 0xFF; DDRC |= ( (1<<INV0_PIN_N) | (1<<INV1_PIN_N) | (1<<WE_PIN_N) );}



#endif
